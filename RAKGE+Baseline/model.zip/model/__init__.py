from .gcns import GCN_TransE, GCN_DistMult, GCN_ConvE
